##########
## 
## Causal Inference Workshop 2022
## Isa Steinmann
##
## Session 5: Regression Models
##
##########

library("EdSurvey")


##########
##
## STEP 1: Load data (PIRLS 2016: Germany)

# downloading and reading data with EdSurvey
downloadPIRLS("C:/Users/isast/Desktop", years = c(2016))
PIRLS2016DEU <- readPIRLS("C:/Users/isast/Desktop/PIRLS/2016", countries = c("deu"))

# or open prepared RData file
load("C:/Users/isast/Desktop/PIRLS2016DEU.RData")


##########
##
## STEP 2: Identify variables of interest

View(showCodebook(PIRLS2016DEU))

# outcome: reading achievement in grade 4
showPlausibleValues(PIRLS2016DEU) # "rrea" is stem of 5 plausible values of overall reading scale
summary2(PIRLS2016DEU, variable = c("rrea"), weightVar = c("totwgt"))

# treatment: preschool attendance (collapsing rare categories to attain binary treatment variable)
summary2(PIRLS2016DEU, variable = c("asdhaps"), weightVar = c("totwgt"))
PIRLS2016DEUrec <- recode.sdf(PIRLS2016DEU, 
                              recode = list(asdhaps=list(from=c("DID NOT ATTEND",
                                                                "1 YEAR OR LESS",
                                                                "2 YEARS"), 
                                                         to=c("LESS THAN 3 YEARS")),
                                            asdhaps=list(from=c("OMITTED OR INVALID"),
                                                         to=NaN)))
summary2(PIRLS2016DEUrec, variable = c("asdhaps"), weightVar = c("totwgt"))

# control variables: 
# highest parental education level (collapsing categories)
summary2(PIRLS2016DEUrec, variable = c("asdhedup"), weightVar = c("totwgt")) 
PIRLS2016DEUrec <- recode.sdf(PIRLS2016DEUrec,
                              recode = list(asdhedup=list(from=c("POST-SECONDARY BUT NOT UNIVERSITY",
                                                                 "UPPER SECONDARY",
                                                                 "LOWER SECONDARY",
                                                                 "SOME PRIMARY, LOWER SECONDARY OR NO SCHOOL"),
                                                          to=c("LOWER THAN UNIVERSITY")),
                                            asdhedup=list(from=c("OMITTED OR INVALID"),
                                                          to=NaN)))
summary2(PIRLS2016DEUrec, variable = c("asdhedup"), weightVar = c("totwgt"))

# number of books at home (collapsing categories)
summary2(PIRLS2016DEUrec, variable = c("asbg04"), weightVar = c("totwgt")) 
PIRLS2016DEUrec <- recode.sdf(PIRLS2016DEUrec,
                              recode = list(asbg04=list(from=c("NONE OR VERY FEW (0-10 BOOKS)",
                                                               "ENOUGH TO FILL ONE SHELF (11-25 BOOKS)",
                                                               "ENOUGH TO FILL ONE BOOKCASE (26-100 BOOKS)"),
                                                          to=c("UP TO 100 BOOKS")),
                                            asbg04=list(from=c("ENOUGH TO FILL TWO BOOKCASES (101-200 BOOKS)",
                                                               "ENOUGH TO FILL THREE OR MORE BOOKCASES (MORE THAN 200)"),
                                                        to=c("MORE THAN 100 BOOKS")),
                                            asbg04=list(from=c("OMITTED OR INVALID"),
                                                          to=NaN)))
summary2(PIRLS2016DEUrec, variable = c("asbg04"), weightVar = c("totwgt"))

# speaking German at home (collapsing categories)
summary2(PIRLS2016DEUrec, variable = c("asbg03"), weightVar = c("totwgt")) 
PIRLS2016DEUrec <- recode.sdf(PIRLS2016DEUrec,
                              recode = list(asbg03=list(from=c("I ALWAYS SPEAK <LANGUAGE OF TEST> AT HOME"),
                                                        to=c("ALWAYS GERMAN")),
                                            asbg03=list(from=c("I ALMOST ALWAYS SPEAK <LANGUAGE OF TEST> AT HOME",
                                                               "I SOMETIMES SPEAK <LANGUAGE OF TEST> AND SOMETIMES SPEAK ANOTHER LANGUAGE AT HOME",
                                                               "I NEVER SPEAK <LANGUAGE OF TEST> AT HOME"),
                                                        to=c("NOT (ALWAYS) GERMAN")),
                                            asbg03=list(from=c("OMITTED OR INVALID"),
                                                        to=NaN)))
summary2(PIRLS2016DEUrec, variable = c("asbg03"), weightVar = c("totwgt"))
         

##########
##
## STEP 3: Compare treatment and control groups in terms of control variables (balance check)

# parental education
summary2(PIRLS2016DEUrec, variable = c("asdhaps", "asdhedup"), weightVar = c("totwgt")) 
# -> children with 3 years or more preschool attendance have on average more educated parents

# books at home
summary2(PIRLS2016DEUrec, variable = c("asdhaps", "asbg04"), weightVar = c("totwgt")) 
# -> children with 3 years or more preschool attendance have on average more books at home

# speaking German at home
summary2(PIRLS2016DEUrec, variable = c("asdhaps", "asbg03"), weightVar = c("totwgt")) 
# -> children with 3 years or more preschool attendance speak more often always German at home


##########
## 
## STEP 4: Stepwise regressions

# regression of reading achievement on preschool variable, no control variables
summary(lm.sdf(rrea ~ asdhaps, data = PIRLS2016DEUrec, weightVar = c("totwgt"))) 
# -> children with less than 3 years of preschool attendance score ca. 20 points lower (p < .001)

# regression of reading achievement on preschool variable, control of parental education
summary(lm.sdf(rrea ~ asdhaps + asdhedup, data = PIRLS2016DEUrec, weightVar = c("totwgt"))) 
# -> after control, children with less than 3 years of preschool attendance score only ca. 15 points lower (p < .001)

# regression of reading achievement on preschool variable, control of parental education and books at home
summary(lm.sdf(rrea ~ asdhaps + asdhedup + asbg04, data = PIRLS2016DEUrec, weightVar = c("totwgt"))) 
# -> after control, children with less than 3 years of preschool attendance score only ca. 10 points lower (p < .01)

# regression of reading achievement on preschool variable, control of parental education, books at home, and language at home
summary(lm.sdf(rrea ~ asdhaps + asdhedup + asbg04 + asbg03, data = PIRLS2016DEUrec, weightVar = c("totwgt"))) 
# -> after control, children with less than 3 years of preschool attendance score only ca. 8 points lower (p < .01)


##########
##
## -> After including only 3 binary control variables, the 20-point reading advantage of children with at least 3 years of 
## preschool attendance decreases to 8 points.
## 
## What if we include more or other control variables?
## What if we specify treatment variable differently?
##
##########

