####################
##
## Causal Inference Seminar
## Isa Steinmann
## 
## Material 1 Session 9
## 
####################

library(ggplot2)
rm(list = ls())

## load data (Norway TIMSS 1995, Pop. A)

load("C:/Users/isa_s/Desktop/TIMSS1995NORpopA.RData")
head(TIMSS1995NORpopA)

## codebook
# "IDSCHOOL"  school ID
# "IDSTUD"    student ID
# "TOTWGT"    total student sampling weight
# "COMPLIER"  complier dummy (0=no, 1=yes)
# "ANALYSIS"  analysis sample dummy (0=no, 1=yes)
# "TTIME"     date of test
# "BTIME"     date of birth 
# "AGE_RAW"   student age in months at time of test
# "AGE_CUT"   student age in months relative to cut-off date
# "IDGRADE"   grade label
# "ADDYEAR"   added-year dummy (0=lower grade, 1=upper grade)
# "ASBGBOOK"  number of books at home (1-5)
# "ITSEX"     student sex (1=girl, 2=boy) 
# "ASMMAT01" "ASMMAT02" "ASMMAT03" "ASMMAT04" "ASMMAT05" plausible values math
# "ASSSCI01" "ASSSCI02" "ASSSCI03" "ASSSCI04" "ASSSCI05" plausible values science

## simple scatterplot
plot(ASMMAT01 ~ AGE_CUT, data=subset(TIMSS1995NORpopA, ANALYSIS==1))
# note that this bases on only 1 plausible value and unweighted data.

## plot of means
math_means <- as.data.frame(aggregate(subset(TIMSS1995NORpopA, ANALYSIS==1)$ASMMAT01,
                              by=list(subset(TIMSS1995NORpopA, ANALYSIS==1)$AGE_CUT),
                              mean))
colnames(math_means) <- c("AGE_CUT", "M_ASMMAT01")
ggplot(math_means, aes(x=AGE_CUT, y=M_ASMMAT01)) +
  geom_point()

## mean difference between lower and upper grade
summary(lm(ASMMAT01 ~ ADDYEAR, data=subset(TIMSS1995NORpopA, ANALYSIS==1), weights=TOTWGT)) 
# note that 91 point difference reflects both age and schooling effects.
# note that we use only 1 plausible value for sake of simplicity, which leads
# to underestimation of standard errors. Analyses in Steinmann & Olsen (under
# review) were run with Mplus.

## simple student-level regression
summary(lm(ASMMAT01 ~ ADDYEAR + AGE_CUT, data=subset(TIMSS1995NORpopA, ANALYSIS==1), weights=TOTWGT))
# note that 61 points reflect effect of 1 additional year of schooling. 2 points
# reflect effect of 1 additional month of age.
2.4906*12 # 30 points reflect effect of 1 additional year of age.
# note that again, analyses base on only 1 plausible value.

## simple RDD plot including means
math_means$ADDYEAR <- ifelse(math_means$AGE_CUT <=0, 0, 1) 
math_means$ESTIMATE <- c(398.4328 + math_means$ADDYEAR * 60.7633 + math_means$AGE_CUT * 2.4906)
ggplot(math_means, aes(x=AGE_CUT, y=M_ASMMAT01)) +
  geom_point() +
  geom_line(aes(x=AGE_CUT, y=ESTIMATE, group=as.factor(ADDYEAR)))
# note that again, analyses base on only 1 plausible value.



